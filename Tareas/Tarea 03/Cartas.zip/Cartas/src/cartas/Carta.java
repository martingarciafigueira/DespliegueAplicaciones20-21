package cartas;

public class Carta {
/**
* Numero de la baraja 
*/
    private int numero;
    
/**
* Palo de la baraja 
*/    
    private int palo;
    
    /**
     * Asocia un numero y un palo a una carta
     * @param numero
     * @param palo 
     */
    public Carta(int numero, int palo) {
        this.numero = numero;
        this.palo = palo;
    }
    /**
     * 
     * @return el numero de la carta
     */
    public int getNumero() {
        return numero;
    }
    /**
     * 
     * @return el palo de la carta
     */
    public int getPalo() {
        return palo;
    }
    /**
     * 
     * @param numero será el valor numerico que tendrá la carta
     */
    public void setNumero(int numero) {
        this.numero = numero;
    }
    /**
     * 
     * @param palo será el palo que tendrá la carta
     */
    public void setPalo(int palo) {
        this.palo = palo;
    }
    /**
     * 
     * @return frase que describirá al carta (incluye su palo y su numero)
     */
    @Override
    public String toString(){
        return "La carta es el " + this.numero + " de " + this.palo + "<br>";
    }
    
}
