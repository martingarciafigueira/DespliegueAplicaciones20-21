package cartas;

public abstract class Baraja implements BarajaCartas {

    /**
    * Array de cartas.
    */
    protected Carta[] cartas;
    
    /**
    * Posición de la siguiente carta.
    */
    protected int posSiguienteCarta = 0;
    
    /**
    * numero total de cartas.
    */
    protected static int NUM_CARTAS = 40;

    /**
    * devuelve las cartas de que se encuentran en el Array
    @return el array Carta[]
    */
    public Carta[] getCartas() {
        return cartas;
    }
    /**
    * devuelve la posicion de la siguiente carta
    *@return la variable posSiguienteCarta
    */
    public int getPosSiguienteCarta() {
        return posSiguienteCarta;
    }
     /**
    * devuelve el numero total de cartas
    *@return la variable num_cartas
    */
    public static int getNUM_CARTAS() {
        return NUM_CARTAS;
    }
    /**
    * Denomina el valor de las cartas dentro del Array
    */
    public void setCartas(Carta[] cartas) {
        this.cartas = cartas;
    }
    
    /**
    * Denomina el valor de la siguiente carta
    * @param posSiguienteCarta se modifica (set) su valor.
    */
    public void setPosSiguienteCarta(int posSiguienteCarta) {
        this.posSiguienteCarta = posSiguienteCarta;
    }
    
    /**
    * Al estar protegido necesita este metodo, pero el valor es el mismo
    * @param NUM_CARTAS permanece con su valor.
    */
    public static void setNUM_CARTAS(int NUM_CARTAS) {
        NUM_CARTAS = NUM_CARTAS;
    }
    
    /**
    * Pone en la ultima posicion a una nueva carta
    * @param unaCarta (objeto).
    */
    protected void addCarta(Carta unaCarta) {
        this.cartas[cartas.length - 1] = unaCarta;
    }
    
    /**
    * Metodos abstractos implementados.
    */
    abstract void crearBaraja();

    public void barajar() {
    }

    public void siguienteCarta() {
    }

    public void cartasDisponibles() {
    }

    public void repartirCartas(int cartasPedidas) {
    }

    public void cartasRepartidas() {
    }

    public void mostrarBaraja() {
    }

}
