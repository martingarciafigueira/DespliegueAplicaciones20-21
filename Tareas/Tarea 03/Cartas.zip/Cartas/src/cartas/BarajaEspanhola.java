package cartas;

public class BarajaEspanhola extends Baraja {
/**
* incluir8y9 se declara en false ya que ne la baraja española carece de los mismos
*/
    protected boolean incluir8y9 = false;

    public void crearBaraja() {
    }
/**
*devuelve true o false si contiene 8y9
*@return devuelve el resultado de incluir8y9
*/
    public boolean getIncluir8y9() {
        return this.incluir8y9;
    }
/**
*puede modificar de true a false la variable incluir8y9
*@param incluir8y9 la variable mencionada    
*/
    public void setIncluir8y9(boolean incluir8y9) {
        this.incluir8y9 = incluir8y9;
    }
    
/**
*compara una dos objetos de tipo baraja e indica si son del mismo tipo
*/
    public void compareTo(Baraja baraja) {
        if (baraja instanceof BarajaEspanhola) {
            System.out.println("Las dos barajas son españolas");
        }
        else
        {
            System.out.println("Las barajas son diferentes");
        }
    }    

}
