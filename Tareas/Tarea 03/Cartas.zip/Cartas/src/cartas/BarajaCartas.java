package cartas;
 /*
  * Metodo que baraja las cartas
  */
interface BarajaCartas {
    public void compareTo(Baraja $baraja);
    
}
