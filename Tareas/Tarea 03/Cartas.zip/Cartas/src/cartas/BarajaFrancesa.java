package cartas;

public class BarajaFrancesa extends Baraja {

    
/**
*Crea una baraja  
*/
    public void crearBaraja() {
    }

/**
*Comapara entre dos objetos de tipo baraja y dice si es igual a esta (francesa)
*/
    public void compareTo(Baraja baraja) {
        if (baraja instanceof BarajaFrancesa) {
            System.out.println("Las dos barajas son francesas");
        } else {
            System.out.println("Las barajas son diferentes");
        }
    }

}
